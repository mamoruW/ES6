'use strict'

//	sample1	---------------------------------------------------------------------
if(0) {
  var spam = 12;// 当然よろしい
  var spam = 13;// （再宣言）これもオッケー
  console.log('sample1 result1:spam = ' + spam);//13

  let ham = 15;//大丈夫
  ham = 17;//（データ入れ替え）問題なし
  console.log('sample1 result2:ham = ' + ham);

  //let ham = 12;//（再宣言）こいつはダメ
}

//	sample2		---------------------------------------------------------------------
if(0) {

  const TEST21 = 11;//大丈夫
  //		TEST21 = 12; //（宣言時の値を変えれない）代入ができない　エラーが返ってくる

  const TEST22 = {
         a: 1,
         b: 0
     };
  TEST22.a = 3;

  console.log('sample2 result1:TEST22  = ' + TEST22);//Object {a: 3, b: 0}
}

//	sample3		---------------------------------------------------------------------
if(0) {
  const TEST3 = Object.freeze({
         a: 1,
         b: 0
     });

  //error160907 TEST3.a = 3;

  console.log('sample3 result1:TEST3  = ' + TEST3);//Cannot assign to read only property 'a' of object '#<Object>'
}

//	sample4		---------------------------------------------------------------------
if(0) {
  for (var i = 0; i < 10; i++) {
      console.log('sample4 result1:i  = ' + i); // 1~9まででる
  }
   
  console.log('sample4 result2:i  = ' + i); //10がでる

  					//	var = i;がない場合でも巻き上げにより同様
  for (i = 0; i < 10; i++) {
      console.log('sample4 result3:i  = ' + i); // 1~9まででる
  }
   
  console.log('sample4 result4:i  = ' + i); //10がでる
}

//	sample5		---------------------------------------------------------------------
if(0) {
  for (let i = 0; i < 10; i++) {
  　　　　console.log('sample5 result1:i  = ' + i); // 1~9まででる
  }
   
  console.log('sample5 result1:i  = ' + i); //ReferenceError: i is not defined
}

//	sample6		---------------------------------------------------------------------
/* error 160907
var $btns1 = $(".button1"); //10個あったとする
 
for (var i=0,len=$btns1.length; i<len; ++i) {
 
  $btns1.eq(i).on('click',function(){
     console.log('sample6 result1:i  = ' + i);
　　　// どれ押しても10しか出てこない
  });
}

let $btns2 = $(".button2"); //10個あったとする
 
for (let i=0,len=$btns2.length; i<len; ++i) {
 
  $btns2.eq(i).on('click',function(){
     console.log('sample6 result2:i  = ' + i);
     // それぞれ 0.1.2 と出てくる
  });
}
 error 160907	*/

//	sample7		---------------------------------------------------------------------
// テンプレート文字列は「`」バッククォート
var str = `あ
い
う`;

console.log('sample7 result1:str  = ' + str);
/**
 * あ
 * い
 * う
 */


//  sample8   ---------------------------------------------------------------------
var counter1 = (function () {
        //プライベートにしたいプロパティ
        var count = 0;

        return {
            //加算メソッド
            increment: function () {
                count += 1;
                console.log('sample8 result1:count  = ' + count);
            }
        };
    }());

counter1.increment(); //1が出力される
counter1.increment(); //2が出力される

console.log('sample8 result2:count  = ' + counter1.count); //※undefined

function counter2() {
    //プライベートにしたいプロパティ
    var count = 0;

      //加算メソッド
      increment: function () {
          count += 2;
          console.log('sample8 result3:count  = ' + count);
      }
};

counter2.increment(); //1が出力される
counter2.increment(); //2が出力される

console.log('sample8 result4:count  = ' + counter2.count); //※undefined


